# Arescope — Agent Handoff Bundle (NASA Space Apps Challenge 2026)

This zip archive exports everything needed for an incoming agent to understand the **Arescope** project, the **7-slide judge presentation**, all user constraints and pivots from the session, the raw/readable conversation transcript, the verified technical archive, and the 15 workspace-local skills.

---

## Bundle Inventory

- `README_AGENT_HANDOFF.md` — You are here. Rules, constraints, open placeholders, and quick verification workflow.
- `PROJECT_CONTEXT_AND_DECISIONS.md` — Slide-by-slide deck specification, chronological user pivots, full preserved project brief (`mrfenek`), hardware roadmap framing, and verified technical-archive summary.
- `presentation/`
  - `Arescope — NASA Space Apps Challenge 2026.html` — Final **Judge Edition** presentation (`31,203` bytes, 7 slides, Warm Carbon / Copper palette, verified at `1280×720` in headless Google Chrome with zero overflow and zero runtime errors). Originally synced to `C:\Users\Timur\Downloads\Arescope — NASA Space Apps Challenge 2026.html`.
  - `original-presentation.html` — User's pre-edit baseline 7-slide deck (`18,749` bytes) preserved for narrative/structure reference.
  - `verify_slides.mjs` — Portable Node.js headless Chrome CDP verifier & screenshotter (adapted from the session verification script to default to `./Arescope — NASA Space Apps Challenge 2026.html` and `./screenshots/`, or any file/URL passed via `argv[2]`).
  - `screenshots/slide-1.png` .. `slide-7.png` — Exact Chrome `1280×720` PNG renders of the final presentation.
- `transcript/`
  - `SESSION_TRANSCRIPT.md` — Clean Markdown export generated directly from `transcript_full.jsonl` containing every user request verbatim, step-level tool actions, and assistant responses up to bundle assembly.
  - `transcript_full.jsonl` — Untruncated raw Antigravity session JSONL snapshot taken immediately prior to zip packaging.
  - `transcript.jsonl` — Compact Antigravity session JSONL snapshot taken immediately prior to zip packaging.
- `technical-archive/` — Complete **Arescope Technical Archive** (109 files across `00_governance/`..`07_appendices/`, `evidence/`, `skills/`, `AGENTS.md`, `README.md`, `SKILL.md`, `SHA256SUMS.txt`; verified `108` entries passed, `0` failed).
- `local-skills/` — All 15 Arescope/Unity/Quest skills originally installed locally into `.agents/skills/` (never globally).

---

## Non-Negotiable Rules & Constraints From the User

1. **Audience is NASA Space Apps 2026 Judges (NOT Developers):**
   - Keep the deck crisp, visual, and high-level (following the 7-slide structure of `original-presentation.html`).
   - **DO NOT** expose internal codebase architecture (ports, endpoints, SQLite schemas, Unity package locks, internal class names like `WireArescopeScene.Run()`) or internal QA gaps / unverified firmware/scene-wiring issues in the judge slides. (Those belong strictly in `technical-archive/` for engineering work.)
2. **SDM is Cut Out:**
   - Do **not** mention SDM (structured decision model) anywhere. It has been removed from Arescope (`technical-archive/01_scope/01_context.md`, `technical-archive/07_appendices/19_voice_copilot_spec.md`, and confirmed by user).
3. **Quest 3S vs. Target Real EVA Astronaut Helmet:**
   - Present **Meta Quest 3S** accurately as a **temporary standalone testbed/prototyping carrier** proving live depth + true-color capture into Mission Control today.
   - Present the target future hardware as a **real astronaut EVA helmet** fitted with a dedicated small computing module capable of running small local **LLM, ASR, and TTS** models, optional crew health vitals (pulse, blood oxygen), and a full EVA sensor pack (**LiDAR, IR sensors, night-vision IR camera, and IR / UV / visible flashlights**).
4. **Animations Must Stay Smooth & Polished:**
   - Preserve and build upon the CSS/Canvas choreography: `1.8s cubic-bezier(.65,0,.25,1)` Mars orb & concentric orbital arcs (`.ring-rot` + moons), drifting `.neb` nebulae, warp-streak canvas starfield with bokeh & constellation links + shooting stars, blur-scale slide crossfades, staggered `.r` entrance (`calc(.18s + var(--d,0)*.06s)`), self-drawing copper `.hl` rules, card hover lift/glow (`.c`), pulsing `.ar` arrows, `01–07` jump pills, keyboard/touch/fullscreen controls, and `@media (prefers-reduced-motion:reduce)`.
5. **Browser & Skill Hygiene:**
   - Use **Google Chrome** or **Brave** (never Edge) for headless/live visual verification.
   - Keep all 15 Arescope/Quest/Unity skills strictly local to `.agents/skills/` inside the project workspace—never install them globally into user config.
6. **Hackathon Start Gate (`technical-archive/AGENTS.md` & `README.md`):**
   - `technical-archive/` is a clean-room preliminary research/specification archive (short fragments `<=15` lines only, zero secrets, verified evidence tags `[ПРОВЕРЕНО]` / `[ПРЕДПОЛОЖЕНИЕ]` / `[ТРЕБУЕТ ПРОВЕРКИ]`).
   - Product source implementation/rebuilding from the archive must wait until the hackathon officially opens; documentation, presentation work, and research remain allowed.

---

## Remaining Open Placeholders Before Judging

On **Slide 1 (`01 · OVERVIEW`)** and **Slide 7 (`07 · CLOSING`)** of `presentation/Arescope — NASA Space Apps Challenge 2026.html`:
- `[Name] · [Name] · [Name] · [Name]` — Fill in actual team member names.
- `[Contact / demo link]` — Fill in team contact/repo/demo URL alongside `arescope.mrfenek.eu.cc` (preserved from the original deck template).

---

## Re-Verifying the Presentation After Future Edits

Run in PowerShell/Terminal from `presentation/` (requires Node.js + Google Chrome installed at default Windows path or pass `CHROME_PATH` env var):

```powershell
cd presentation
node verify_slides.mjs
```

- Pass a custom file path or URL as `node verify_slides.mjs "C:\path\to\deck.html"` to test an external copy (e.g., `C:\Users\Timur\Downloads\Arescope — NASA Space Apps Challenge 2026.html`).
- Expected clean baseline across all 7 slides at `1280×720`:
  - `overflowY: 0`, `overflowX: 0` on every `.pad`
  - `NAV_CHECK: {"afterKey1":1,"afterArrow":2}`
  - `ERRORS: []`
  - Fresh captures written to `presentation/screenshots/slide-1.png` .. `slide-7.png`.
