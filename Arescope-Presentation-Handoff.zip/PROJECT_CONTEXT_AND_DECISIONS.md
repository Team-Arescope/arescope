# Arescope Project Context, Decisions & Deck Architecture

## 1. Executive Summary (Instant Orientation)

**Arescope** is a unified spatial awareness and mission-support system for Mars surface exploration (NASA Space Apps Challenge 2026).

Three core subsystems form one connected pipeline:
1. **In the Headset (`Spatial Capture & HUD`):** Captures real-time 3D topography and true-color surface textures around the explorer while displaying heading, local session pose, and a hazard minimap in an eye-level optical HUD without GPS.
2. **On Earth (`Mission Control: Arescope LAB`):** Earth-side dashboard (`arescope.mrfenek.eu.cc`) combining static **NASA HiRISE & MOLA orbital terrain archives** with mission routes, live 3D point streams, and downloadable 3D scans.
3. **Hands-Free Guidance (`Voice Copilot`):** Push-to-talk **ASR -> LLM -> TTS** assistant giving concise safety and terrain guidance.

**Key strategic breakthrough highlighted for judges:** Previously, Mars surface maps came solely from static NASA orbital archives; Arescope adds **live human-scale 3D scanning around an explorer** streaming straight into Mission Control (`Meta Quest 3S` standalone carrier today -> dedicated **real astronaut EVA helmet** with local LLM/ASR/TTS compute, optional vitals, **LiDAR**, IR sensors, night-vision IR camera, and IR / UV / visible lights next).

---

## 2. Chronological Session Decisions & Design Pivots

| Turn | User Directive / New Context | Impact on Deliverable |
|---|---|---|
| Turn 1 | Match technical archive + install zip skills locally only (not globally). | Extracted `Arescope-Technical-Archive.zip` (`108` SHA-256 hashes verified), installed 15 skills strictly under `.agents/skills/`. Built initial technical deck (later replaced in Turn 4). |
| Turn 2 | Prefer Chrome or Brave instead of Edge. | Built headless Google Chrome CDP script (`verify_slides.mjs`) at `1280×720` capturing DOM bounds, keyboard nav, runtime errors, and PNG screenshots per slide. |
| Turn 3 | Preserve and upgrade original smooth & stylish animations. | Enhanced orbital Mars arcs (`.ring-rot` counter-rotation + orbiting moons), drifting nebulae, canvas warp-streak starfield + bokeh + constellations + shooting stars, blur-scale slide crossfades, staggered `.r` reveal, self-drawing copper `.hl` dividers, pulsing `.ar` arrows, `01–07` nav pills, and `prefers-reduced-motion` guard. |
| Turn 4 | **CRITICAL PIVOT:** Presentation is for **judges**, NOT team members or developers. Do **NOT** mention extensive architecture internals or known bugs/gaps; base narrative on original presentation text & structure. | Replaced 8-slide engineering audit deck with a focused 7-slide Judge Edition modeled directly on `original-presentation.html`. Removed ports, Unity/FastAPI class names, SQLite internals, and bug/QA gap lists. |
| Turn 5 | Added `mrfenek` project brief + explicit rule: **SDM functionality has been cut out** and is unrelated now. | Aligned copy around unified Arescope system (`Before: NASA archives -> Now: Archives + live scanning`, Quest 3S live capture, HiRISE & MOLA archives, Voice Copilot, crew context) and omitted SDM completely. |
| Turns 6–7 | Clarified hardware roadmap: **Meta Quest 3S is temporary**; target is a **real astronaut helmet** with compact compute for small **LLM, ASR, TTS** + **LiDAR, IR sensors, night-vision IR camera, IR / UV / visible flashlights**. | Updated Slide 2 (`testbed toward a real astronaut helmet module`), Slide 4 (`evolving toward local on-helmet AI`), Slide 5 (`Meta Quest 3S Testbed`), and Slide 6 (`Now · Prototyping` -> `Next · Real EVA Helmet` -> `Vision`). |

---

## 3. Final 7-Slide Deck Map (`Arescope — NASA Space Apps Challenge 2026.html`)

Canvas stage: fixed `1280×720` viewport-scaled coordinate frame (`#stage`), Warm Carbon / Copper palette (`--bg:#0d0907`, `--ink:#100b09`, `--paper:#f5e8df`, `--muted:#b5a69e`, `--rule:#513026`, `--copper:#ee8a5b`, `--panel:rgba(16,11,9,.76)`), typography `Manrope` + `DM Mono`, Tabler outline SVG icons.

| Slide | HUD Tag (`data-label`) | Mars Orb Transform (`data-p`) | Core Message & Visual Layout |
|---|---|---|---|
| **01** | `Overview` | `885,-12,1.24,20` | Title hero: `ARESCOPE` · *A unified system for the Mars expedition* · *Every astronaut a sensor. Every mission a live map.* + `Team Arescope` `[Name]` placeholders. |
| **02** | `The Challenge` | `-115,240,.85,180` | Left narrative framing visor-to-Mission-Control workflow (Meta Quest 3S testbed toward a real astronaut helmet module); Right 3 stacked cards: `01 Delayed link`, `02 Unknown terrain`, `03 Limited crew view`. |
| **03** | `The Headset` | `855,-380,.66,0` | 4-column grid: `01 3D Topography`, `02 Textures & Color`, `03 Local Awareness`, `04 Voice Copilot` (warm highlight). |
| **04** | `System Pipeline` | `930,400,.75,0` | 3-stage flow separated by pulsing arrows (`.ar`): `1 Spatial Capture & HUD` (`IN THE HEADSET`) -> `2 Mission Control: Arescope LAB` (`ON EARTH`, bolding **NASA HiRISE & MOLA archives**) -> `3 Voice Copilot` (`HANDS-FREE GUIDANCE`, evolving toward local on-helmet AI). |
| **05** | `Progress` | `880,-400,.75,0` | Top row `Before -> Now`: *Maps built only from NASA archives* -> *Archives + live scanning around a person*. Bottom 3-step pipeline: `Meta Quest 3S Testbed` -> `Live 3D stream & mesh` -> `Mission Control` (`arescope.mrfenek.eu.cc`). |
| **06** | `Impact & Roadmap` | `900,-420,.72,0` | Top 2 cards: `For the astronaut` & `For Mission Control`. Bottom 3-stage roadmap: `Now · Prototyping` (Quest 3S feeds Mission Control) -> `Next · Real EVA Helmet` (**LLM, ASR & TTS**, optional vitals, **LiDAR**, IR sensors, night-vision IR camera & IR / UV / visible lights) -> `Vision` (fleet platform). |
| **07** | `Closing` | `835,345,1.02,0` | `[Name]` + `[Contact / demo link] · arescope.mrfenek.eu.cc` top metadata, oversized `Thank you`, and tagline at bottom-left opposite framed Mars horizon. |

### Interactive Navigation Built Into the Deck
- Mouse click (`x < 20%` goes back; otherwise advances), ignoring `#nav`, `#dots`, `button`, `a`.
- Keyboard: `ArrowRight`/`ArrowDown`/`PageDown`/`Space`/`Enter` next; `ArrowLeft`/`ArrowUp`/`PageUp`/`Backspace` prev; `Home`/`End`; `1–7` direct slide jump; `F` fullscreen toggle.
- Bottom controls: `#dots` (`01`–`07` jump buttons), `#nav` prev/counter/next/fullscreen buttons, `#bar` linear copper progress bar, fade-out `#hint` after leaving Slide 1, and horizontal touch swipe (`>50px`).

---

## 4. Verbatim User Brief Notes Preserved (`mrfenek`, Session Turn 5)

Included verbatim so no nuance from the team's product framing is lost if a future agent updates slides, writes a pitch script, or builds a web demo:

```text
mrfenek:
В итоге
ОБЩАЯ ИНФОРМАЦИЯ О ПРОЕКТЕ

Arescope — единая система для марсианской экспедиции.

Суть: люди работают на поверхности Марса, а в шлеме у каждого стоит небольшой модуль с датчиками. Он собирает данные, показывает их в шлеме и передаёт в земный центр управления.

Что собирает модуль:
- Топография — 3D-модель местности вокруг человека.
- Текстуры — реальные цвета земли, камней, техники.
- Местоположение астронавта и, по возможности, показатели здоровья: пульс, кислород.
- Локальный ИИ-ассистент прямо в шлеме: распознавание речи, оценка картинки с камеры, языковая модель.

Из этого складываются три подсистемы:

1. Сбор данных. Модуль в шлемме снимает глубину и цвет, строит карту вокруг астронавта, отмечает, где пройдено, и что видно.

2. Центр управления. На Земле панель показывает карту Mission Control: рельеф, точки, открытые участки, положение и состояние людей, события. Сейчас это и есть Arescope LAB — мы делаем его на реальных архивах NASA (HiRISE, MOLA) и проверяем на них.

3. Ассистент. Малые модели работают локально в шлеме, чтобы не зависеть от связи: распознают речь, описывают, что видно, отвечают на вопросы по маршруту. В перспективе — связь с общим ассистентом на базе.

Практическая ценность: астронавт получает подсказки по местности и своему состоянию прямо в шлеме, а центр видит, где люди, что происходит, и может вмешаться.

Где мы сейчас: работаем с Quest 3S как с реальным носителем датчиков. Собранные с него точки уже приходят в Mission Control — в этом и состоит главный выигрыш: до сегодня мы строили карту только по архивам NASA, а теперь добавляется живое сканирование вокруг человека.

mrfenek:
То есть астронавты ходят по Марсу, небольшой модуль с датчиками собирает:
Топографию (3D модель местности)
Текстурирование (реальные цвета и текстуры земли, камней и других объектов)

В планах:
Местоположение астронавта, по возможности показатели здоровья (пульс, кислород в крови, и т.д.)
Небольшие локальные ИИ модели для ассистента внутри шлема: ASR, SDM и LLM - первые 2 около 0.5 миллиарда параметров, а LLM 1-4 миллиарда

mrfenek:
Arescope Copilot может объединить их в одну систему поддержки марсианской экспедиции: карта помогает понять, куда идёт экипаж, а мониторинг — в каком состоянии он находится во время миссии.

Я бы выбрал Martian Map как основной челлендж, а Crew Health Monitoring сделал частью сценария. Так проект остаётся сфокусированным: здоровье не отдельный дашборд ради галочки, а дополнительная информация для подготовки и выполнения выхода.

Как выглядит единая система

1. Подготовка миссии
На карте Mission Control команда:
- выбирает район и научные точки;
- прокладывает маршрут;
- видит доступные слои данных NASA;
- задаёт длительность миссии и состав экипажа;
- получает брифинг с маршрутом и условиями сценария.

2. Выход на поверхность
В браузерном 3D-режиме или VR астронавт:
- видит маршрут и следующий ориентир;
- отмечает прибытие к научной точке;
- может сообщить о проблеме или запросить связь с командным центром.

3. Мониторинг экипажа
На панели Mission Control рядом с картой отображаются:
- участники миссии и их положение;
- длительность выхода;
- данные состояния экипажа;
- уведомления и история событий.

Для MVP показатели можно генерировать синтетически и явно подписать как симуляцию. Без часов и других датчиков не нужно создавать видимость реальных измерений.

4. Совместное решение
Допустим, во время демонстрации симулятор показывает изменение состояния одного участника. Система не ставит диагноз, а предлагает оператору рассмотреть варианты:
- продолжить миссию;
- сделать паузу;
- вернуться к точке старта.
Оператор видит маршрут и данные состояния в одном контексте и сам принимает решение. Вот здесь объединение двух направлений действительно работает.

Роли моделей
- LLM: брифинг миссии, сводка событий и объяснение доступных данных со ссылками.
- SDM: структурированное сравнение вариантов по заданным критериям: длительность, расстояние, состояние сценария и другие доступные показатели.
- VLM: опциональный анализ снимков местности или изображений научных объектов.

Числовые показатели, расстояния и события рассчитывает код/симулятор. Модели помогают сопоставить и объяснить, а не заменяют сами данные.

Один убедительный демо-сценарий
Два астронавта готовятся посетить геологическую точку. Mission Control выбирает маршрут и отправляет брифинг. Во время выхода у одного участника меняется синтетический показатель нагрузки. Панель показывает событие и предлагает сравнить продолжение, паузу и возвращение. Оператор выбирает паузу; событие появляется в журнале миссии.
Это можно показать и без шлема. Если Quest доступен, вид астронавта усиливает презентацию, но не должен быть единственным способом запустить демо.

Что вошло бы в MVP
1. Один район Марса с реальными данными и источниками.
2. Один маршрут с несколькими точками.
3. Карта Mission Control и вид астронавта в браузере.
4. Один-два участника с синтетическими показателями.
5. Одно событие и сравнение вариантов реакции.
6. LLM-брифинг и журнал миссии.

VR, VLM и сложный мониторинг — следующий слой, если базовый сценарий уже работает.

Позиционирование: Arescope Copilot — единая панель подготовки и сопровождения марсианской экспедиции, объединяющая данные местности и состояние экипажа.
```

> **IMPORTANT OVERRIDE FROM USER (Turn 5 + Technical Archive verification):**
> - **SDM is removed/cut out** (`DO NOTE - that SDM functionality has been currently cut out, it's unrelated now`). Both the user and `technical-archive/01_scope/01_context.md` + `technical-archive/07_appendices/19_voice_copilot_spec.md` confirm SDM is excluded; Voice Copilot handles **ASR, LLM, TTS** only.
> - **Optional synthetic crew metrics caution:** `mrfenek` explicitly notes telemetry/vitals should never be misrepresented as real sensor data when simulated. Because the Judge Edition presentation focuses tightly on the verified core + EVA helmet roadmap, optional vitals (`optional vitals`) appear on Slide 6 under the future `Real EVA Helmet` step rather than claiming active physiological sensing today.

---

## 5. Ground-Truth Technical Archive Reference (Engineering Only — Do Not Leak Into Judge Slides)

When working on implementation/architecture after reading `technical-archive/AGENTS.md`:
- **Headset Prototype (Current Testbed):** Meta Quest 3S (Android ARM64), Unity `6000.2.9f1`, Meta XR Core/MRUK `205.0.0`, AR Foundation `6.2.0`, OpenXR `1.15.1`, Input System `1.14.2`, RoomScan SDK pinned revision `4791b24b81015641d4cfb010a93c6283d4eb3dee` (TSDF + GPU Surface Nets meshing, HUD, LiveScanPoints, minimap).
- **Mission Control (`Arescope LAB`):** FastAPI service (`127.0.0.1:18965`, SQLite `live.sqlite3` + `/mesh` & device logs), public origin `https://arescope.mrfenek.eu.cc`.
- **Voice Copilot (`arescope-beta02-core`):** FastAPI service (`127.0.0.1:18975`) relaying via OmniRoute (`http://127.0.0.1:20128/v1`):
  - `POST /api/copilot/transcribe` -> `groq/whisper-large-v3-turbo`
  - `POST /api/copilot/chat` (SSE) -> `cx/gpt-6-luna`, `th/glm-5.3-flash`, `th/gpt-6-luna`, `agy/gemini-3.8-flash-tiered`
  - `POST /api/copilot/speech` -> `minimax/speech-2.8-hd` (`male -> Deep_Voice_Man`, `female -> Calm_Woman`)
- **Known Engineering Blockers & Status (`07_appendices/25_evidence_ledger.md`, `27_scene_build_audit.md`):** Latest confirmed headset log boot marker is `app=0.5.8` (`20261113-081211-pause.log`); APK `0.5.12` / `versionCode 33` artifact verified via `aapt2` and SHA-256 (`bf293ae...`), while scene wiring (`WireArescopeScene.Run()` / `ViewModeController` null refs) and on-device runtime telemetry remain tracked as open engineering verification items inside `technical-archive/`.
- **15 Local Archive Skills (`local-skills/`):** `arescope-beta02-build-loop`, `arescope-clean-room-archive`, `arescope-lab`, `quest-openxr-diagnostics`, `quest-openxr-runtime-debugging`, `quest-scan-visualization`, `quest-world-space-hud`, `quest-xr-diagnostics`, `unity-android-build`, `unity-android-builds`, `unity-android-headless-build`, `unity-android-headless-builds`, `unity-headless-builds`, `unity-quest-xr-diagnostics`, `unity-quest-xr-wiring`.
